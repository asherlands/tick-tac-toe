const statusEl = document.getElementById('status');
const boardEl = document.getElementById('board');
const cells = document.querySelectorAll('.cell');
const resetBtn = document.getElementById('resetBtn');

let socket = null;
let you = null;
let running = false;
let turn = null;

function connect() {
  socket = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws');

  socket.addEventListener('open', () => {
    statusEl.textContent = 'Connected. Waiting for players...';
  });

  socket.addEventListener('message', (event) => {
    const data = JSON.parse(event.data);
    if (data.type === 'init') {
      you = data.you;
      running = data.running;
      turn = data.turn;
      renderBoard(data.board);
      statusEl.textContent = `You are ${you}. ` + (running ? `Turn: ${turn}` : 'Waiting for opponent...');
    } else if (data.type === 'state') {
      running = data.running;
      turn = data.turn;
      renderBoard(data.board);
      statusEl.textContent = `Players: ${data.players_count}. ` + (running ? `Turn: ${turn}` : 'Waiting...');
    } else if (data.type === 'update') {
      renderBoard(data.board);
      turn = data.turn;
      statusEl.textContent = `Turn: ${turn}`;
    } else if (data.type === 'end') {
      renderBoard(data.board);
      running = false;
      if (data.winner) {
        statusEl.textContent = `Game over — Winner: ${data.winner}`;
      } else {
        statusEl.textContent = 'Game over — Tie';
      }
    } else if (data.type === 'reset') {
      renderBoard(data.board);
      running = data.running;
      turn = data.turn;
      statusEl.textContent = running ? `Turn: ${turn}` : 'Waiting for players...';
    } else if (data.type === 'full') {
      statusEl.textContent = 'Room full — try opening in another browser or tab';
    } else if (data.type === 'player_left') {
      statusEl.textContent = 'Player left — waiting for opponent...';
      renderBoard([null, null, null, null, null, null, null, null, null]);
    } else if (data.type === 'error') {
      console.warn('Server error:', data.message);
    }
  });

  socket.addEventListener('close', () => {
    statusEl.textContent = 'Disconnected';
  });
}

function renderBoard(board) {
  board.forEach((v, i) => {
    cells[i].textContent = v || '';
  });
}

cells.forEach(cell => {
  cell.addEventListener('click', () => {
    const idx = parseInt(cell.dataset.index, 10);
    if (!running) return;
    if (turn !== you) return;
    if (cell.textContent) return;

    socket.send(JSON.stringify({ type: 'move', index: idx }));
  });
});

resetBtn.addEventListener('click', () => {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({ type: 'reset' }));
  }
});

connect();